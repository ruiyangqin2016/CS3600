Regarding to problem5, problem6, problem7 
please use the commend: 
	python q5.py
	python q6.py
	python q7.py 
or switch python to pypy. Using python2.